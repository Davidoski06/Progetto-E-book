package ebookClient;

import java.io.*;
import java.net.*;

public class EbookClient {

    private static final String SERVER_ADDRESS = "127.0.0.1";
    private static final int PORT = 12348;
    public static void main(String[] args) {
        //---Apertura della connessione con il server
        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
             BufferedReader serverReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter serverWriter = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))) {

            String serverMessage;

            //---Messaggio di benvenuto e dei comandi disponibili
            while ((serverMessage = serverReader.readLine()) != null) {
                System.out.println("SERVER: " + serverMessage);
                if (serverMessage.contains("Comandi disponibili")) {
                    break;
                }
            }

            String command;
            while (true) {
                System.out.print("Inserisci un comando: ");
                command = consoleReader.readLine(); //---Lettura del comando dalla console
                serverWriter.println(command); //---Invio del comando al server

                if (command.equalsIgnoreCase("EXIT")) {
                    System.out.println("Connessione chiusa.");
                    break; //---Esce dal ciclo principale
                }

                //---Legge la risposta dal server fino al segnale "END_RESPONSE"
                while ((serverMessage = serverReader.readLine()) != null) {
                    if (serverMessage.equals("END_RESPONSE")) {
                        break;
                    }
                    System.out.println("SERVER: " + serverMessage);
                }
            }
        } catch (IOException e) {
            System.err.println("Errore di connessione: " + e.getMessage());
        }
    }
}
