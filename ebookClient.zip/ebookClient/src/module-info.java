/**
 * 
 */
/**
 * 
 */
module ebookClient {
}