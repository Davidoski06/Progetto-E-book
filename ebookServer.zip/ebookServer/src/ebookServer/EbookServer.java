package ebookServer;

import java.io.*;
import java.net.*;

public class EbookServer {

    private static final int PORT = 12348;

    public static void main(String[] args) {
        System.out.println("Server avviato...");

        //---Crea il server socket che accetta connessioni
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nuovo client connesso.");

                //---Passa la gestione del client alla classe ClientHandler
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Errore del server: " + e.getMessage());
        }
    }
}
