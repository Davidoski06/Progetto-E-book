package ebookServer;

import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {

    private final Socket clientSocket; 
    private static final String BOOKS_DIRECTORY = "ebooks"; //---Cartella in cui sono salvati i libri

    //---Costruttore
    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        //---Uso di try per chiudere automaticamente le risorse (BufferedReader e PrintWriter)
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)) {

            //---Invio al client del messaggio di benvenuto e dei comandi disponibili
            writer.println("Benvenuto al server ebook!");
            writer.println("Comandi disponibili: LIST, VISUALIZZA <nome file>, EXIT");

            String command; //---Stringa per memorizzare il comando inviato dal client

            //---Ciclo per ricevere e gestire i comandi del client
            while ((command = reader.readLine()) != null) {
                if (command.equalsIgnoreCase("LIST")) {
                    listBooks(writer);
                } else if (command.startsWith("VISUALIZZA ")) {
                    String fileName = command.substring(10).trim(); 
                    sendFile(fileName, writer);
                } else if (command.equalsIgnoreCase("EXIT")) {
                    writer.println("Connessione chiusa.");
                    break; //---Esce dal ciclo
                } else {
                    
                    writer.println("Comando non valido.");
                }
                //---Segnale di fine risposta, per permettere al client di sapere che la risposta è terminata
                writer.println("END_RESPONSE");
            }
            System.out.println("Client disconnesso.");
        } catch (IOException e) {
            //---Gestione degli errori di I/O durante la comunicazione con il client
            System.err.println("Errore con il client: " + e.getMessage());
        }
    }

    //---Metodo per elencare i file presenti nella cartella dei libri
    private void listBooks(PrintWriter writer) {
        File directory = new File(BOOKS_DIRECTORY); //---Crea un oggetto File per la cartella dei libri
        if (!directory.exists()) {
            writer.println("La cartella dei libri non esiste.");
            return;
        }

        File[] files = directory.listFiles(); //---Ottiene la lista dei file nella cartella
        if (files == null || files.length == 0) {
            writer.println("Nessun libro disponibile.");
        } else {
            //---Elenco dei file disponibili
            writer.println("Ecco i libri disponibili:");
            for (File file : files) {
                writer.println(file.getName()); // Invia il nome di ciascun file al client
            }
        }
    }

    //---Metodo per inviare il contenuto di un file al client
    private void sendFile(String fileName, PrintWriter writer) {
        File file = new File(BOOKS_DIRECTORY, fileName); //---Crea un oggetto File con il nome specificato
        if (!file.exists()) {
            writer.println("Il file richiesto non esiste.");
            return;
        }

        //---Legge il contenuto del file e lo invia al client riga per riga
        try (BufferedReader fileReader = new BufferedReader(new FileReader(file))) {
            writer.println("Inizio del file:");
            String line;
            while ((line = fileReader.readLine()) != null) {
                writer.println(line); //---Invia ogni riga del file al client
            }
            writer.println("Fine del file."); 
        } catch (IOException e) {
            //---Gestione di eventuali errori durante la lettura del file
            writer.println("Errore durante l'invio del file.");
        }
    }
}
