/**
 * 
 */
/**
 * 
 */
module ebookServer {
}